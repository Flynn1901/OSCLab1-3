//
// Created by flynn on 24-12-25.
//

#ifndef SENSOR_DB_H
#define SENSOR_DB_H
#include "lib/dplist.h"
#include "sbuffer.h"
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
void* stormgr(void*);
#endif //SENSOR_DB_H
